#Region 'PREFIX' -1

prefix.ps1
#EndRegion 'PREFIX'
#Region 'SUFFIX' -1

suffix.ps1
#EndRegion 'SUFFIX'
